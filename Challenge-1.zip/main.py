# This program says hello and asks for my name.

# This program says hello and asks for my name.

print(' hello world!')
print('What is your name?') # ask for their name
myname = input()
print('it is good to meet you,'+ 'myname')
print('The length of your name is:') 
print(len(myname)) 
print('What is your age?') # ask for their age
myAge = input()
print('you will be'+ str(int(myAge) + 1) + ' in a year.')
